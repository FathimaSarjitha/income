<?php

session_start();

include 'include/actions.class.php';
include 'include/Database.class.php';
include 'include/Session.class.php';
include 'include/user.class.php';

global $__site_config;
$__site_config_path = $_SERVER['DOCUMENT_ROOT'].'/db_get_config_.json';
$__site_config = file_get_contents($__site_config_path);

function get_config($key, $default=null)
{
    global $__site_config;
    $array = json_decode($__site_config, true);
    if (isset($array[$key])) {
        return $array[$key];
    } else {
        return $default;
    }
}


//this funtion used to load templates//
function load_template($name)
{
    include $_SERVER['DOCUMENT_ROOT']."/daily-profit/__templates/$name.php";
}

// $action and $id will get the value where the Button clicked in update or delete button
$action = $_POST['action'];
$id = $_POST['id'];

if ($_GET['action'] == 'd') {

    try {
        //this Session::removeUserSession will remove the session information from the database;
        Session::removeUserSession($_GET['token']);
    } catch(Exception) {
    }
    // these two will unset and destory the PHP Session.
    session_unset();
    session_destroy();
    unset($_COOKIE['sessionToken']); 
    setcookie('sessionToken', '', -1, '/')
    // setcookie("sessionToken", "");
    ?>
    <!-- This JS code used to one step back from this load.php -->
<script type="text/javascript">
	history.back();
</script>
<?php
}

if ($action == 'update') {
    $desc = $_POST['description'];
    $date = $_POST['date'];
    $amount = $_POST['amount'];

} 
elseif($action == 'insert') {
    $desc = $_POST['description'];
    $date =$_POST['date'];
    $amount = $_POST['amount'];
    $type = $_POST['type'];

}

switch ($action) {
    // if the value of $action is :update then the return statement will executed and return
    case "update":
        // The Daily::updateEntry will update the database entry withe following arguments...
        return Daily::updateEntry($id, $desc, $date, $amount);
        break;
    case "delete":
        return Daily::deleteEntry($id, $_SESSION['user_id']);
        break;
    case "insert":
        return Daily::insertValues($desc, $date, $amount, $type, $_SESSION['user_id']);
        break;
    // case "incomeList":
    //     $data = array();
    //     $result = Daily::getExpenseList($_SESSION['user_id']);
    //     while ($row = $result->fetch_object()) {
    //         $data[] = $row;
    //     }
    //     return json_encode($data);

}


$get = $_POST['getValue'];

switch ($get) {
    case "income":
        return Daily::getTotal('income', $_SESSION['user_id']);
        break;

    case "expense":
        return Daily::getTotal('expense', $_SESSION['user_id']);
        break;
}


