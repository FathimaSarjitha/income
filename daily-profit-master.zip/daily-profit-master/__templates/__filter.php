<div class="container">
	<?php

	$type = $_POST['filter_type'];
	$type_name = $_GET['dailyincomelist'];
	$webname = basename($_SERVER['PHP_SELF']);

	?>

<div id="active-filter" class="d-flex flex-row mx-2 justify-content-end">
			<img src="libs/img/11.png" alt="filter" height="50px">
		</div>
	<div id="toggle_filter">
<?
		if ($webname == 'table.php'){
?>
		<form method="POST" action="<?=$webname?>?dailyincomelist=<?=$type_name?>">
<?} else{?>
	
	<form method="POST" action="<?=$webname?>">
	<?}?>
			<div id="show-filter" class="row d-none flex-row mx-2 justify-content-center mt-4 fw-bold ">

				<div class="px-2">
					<label><input type="radio" name="filter_type" value="week">
						This Week</label>
				</div>
				<div class="px-2">

					<label><input type="radio" name="filter_type" value="month">
						This Month</label>
				</div>
				<div class="px-2">

					<label><input type="radio" name="filter_type" value="year">
						This Year</label>
				</div>
				<div class="px-2">

					<label><input type="radio" id="custom" name="filter_type" value="date"> Custom Date</label>
				</div>
				<div class="px-2">

					<label><input type="radio" id="default" name="filter_type" value="default"> Default</label>
				</div>


			</div>


			<div id="custom-filter" class="row d-none flex-row mx-2 justify-content-center">
				<div class="px-4">
					<label>From</label>
					<input type="date" name="start_date" class="form-control">
				</div>

				<div class="px-4">
					<label for="">To</label>
					<input type="date" name="end_date" class="form-control">
				</div>
			</div>

			<div id="filter-options" class="d-none flex-row mx-2 mt-4 justify-content-end">
				<button id="apply-filter" class="mx-3 border-1 rounded p-1 bg-primary" type="submit">Filter</button>
				
				<button id="cancel-filter" class="rounded border-1 p-1  bg-danger" type="reset" >Cancel</button>
			</div>
</form>

			

	</div>





</div>
</div>
</div>
</div>
<!-- 
<h1 id="result"></h1> -->
<!-- <script>
	const btn = document.querySelector('#apply-filter');
	const radioButtons = document.querySelectorAll('input[name="filter_type"]');
	btn.addEventListener("click", () => {
		let selectedSize;
		for (const radioButton of radioButtons) {
			if (radioButton.checked) {
				selectedSize = radioButton.value;
				break;
			}
		}
		// show the output:
		result.innerText = selectedSize ? `You selected ${selectedSize}` : `You haven't selected any size`;
	});
</script> -->